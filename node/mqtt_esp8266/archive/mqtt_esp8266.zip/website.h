const char website_content[] PROGMEM = R"=====(
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!--<link rel="stylesheet" href="/style.css" type="text/css" />-->
  <!--<script src="/microajax.js"></script>--> <!-- Adding microajax  -->
  <h1>ESP Home</h1>

  <h4>Settings</h4>
  <div class="grid">

  <label>ssid</label>
  <input type="text" id="ssid"></input>

  <label>password</label>
  <input type="text" id="password"></input>

  <label>station ID</label>
  <input type="text" id="station_id"></input>

  <label>mqtt broker</label>
  <input type="text" id="mqtt_broker"></input>

  <label>mqtt topic</label>
  <input type="text" id="mqtt_topic"></input>

  <label>mqtt user</label>
  <input type="text" id="mqtt_user"></input>

  <label>mqtt pass</label>  
  <input type="text" id="mqtt_pass"></input>

  <label>server port</label>
  <input type="number" id="server_port"></input>

  <label>baud rate</label>
  <input type="number" id="baud_rate"></input>

  <div>
  <button class="mybutton" onclick="refresh();">Load settings</button>
  </div>
  <div>
  <button class="mybutton" onclick="submit();">Save settings</button>
  </div>
  </div>

  <h4>Info</h4>
  <div class="grid">
  <label>MAC address</label>
  <input type="text" id="mac_address"></input>
  <label>Station IP</label>
  <input type="text" id="station_ip"></input>
  <label>Signal strength (RSSI)</label>
  <input type="text" id="rssi"></input>
  <label>Free RAM (bytes)</label>
  <input type="text" id="free_ram"></input>
  </div>

  <script>

  var tcp_data_log="";
  var serial_data_log="";
  var myTimer1;

  var keysConfig = ["ssid", "password", "mqtt_broker", "mqtt_topic", "mqtt_user", "mqtt_pass", "server_port", "baud_rate", "station_id", "mac_address"];
  var keysInfo = ["station_ip", "rssi", "free_ram"];

  function microAjax(options) {
    "use strict";

    // Default to GET
    if (!options.method) {
      options.method = "GET";
    }

    // Default empty functions for the callbacks
    function noop() {}
    if (!options.success) {
      options.success = noop;
    }
    if (!options.warning) {
      options.warning = noop;
    }
    if (!options.error) {
      options.error = noop;
    }

    var request = new XMLHttpRequest();
    request.open(options.method, options.url, true);
    request.send(options.data);

    request.onload = function() {
      // Success!
      if (request.readyState === 4 && request.status === 200) {
        options.success(request.responseText);

        // We reached our target destination, but it returned an error
      } else {
        options.warning();
      }
    };

    // There was a connection error of some sort
    request.onerror = options.error;
  }

  function getValues(text){
    document.getElementById("mydynamicdata").value = text;
  }


  var getInfoData = function(){
    microAjax({
      url: "/data/info",
      method: "GET",
      success: function(string){
        var obj = JSON.parse(string);

        if (obj.flag_serial==1){
          serial_data_log+=(obj.serial_in);
        }
        if(obj.flag_tcp==1){
          tcp_data_log+=(obj.tcp_in);
        }
        var textarea;

        // document.getElementById("serial_data").innerHTML = serial_data_log;
        // document.getElementById("tcp_data").innerHTML = tcp_data_log;

        // textarea = document.getElementById('serial_data');
        // textarea.scrollTop = textarea.scrollHeight;
        // textarea = document.getElementById('tcp_data');
        // textarea.scrollTop = textarea.scrollHeight;

        for(let key of keysInfo){
          document.getElementById(key).value = obj[key];
        }
      }
      /* Successful request callback */,
      warning: function(value){
        console.log("warning");
        console.log(value);
      }
      /* Request warning callback */,
      error: function(value){
        console.log("error");
        console.log(value);
      }
      /* Request error callback */
    });
  };

  var refresh = function(){
    console.log("refresh");
    microAjax({
      url: "/data/config",
      method: "GET",
      success: function(string){
        var obj = JSON.parse(string);
        console.log(string);
        console.log(obj);
        for(let key of keysConfig){
          document.getElementById(key).value = obj[key];
        }
      }
      /* Successful request callback */,
      warning: function(value){
        console.log("warning");
        console.log(value);
      }
      /* Request warning callback */,
      error: function(value){
        console.log("error");
        console.log(value);
      }
      /* Request error callback */
    });
  };

  var submit = function(){
    console.log("submit");

    var obj = {};

    for(let key of keysConfig){
      obj[key] = document.getElementById(key).value;
    }

    microAjax({
      url: "/data/config",
      method: "POST",
      data: JSON.stringify(obj),
      success: function(string){
        console.log("post success");
      }
      /* Successful request callback */,
      warning: function(value){
        console.log("warning");
        console.log(value);
      }
      /* Request warning callback */,
      error: function(value){
        console.log("error");
        console.log(value);
      }
      /* Request error callback */
    });
  };


  // init
  refresh();

  function myTimerFunction1() {
    myTimer1 = setTimeout(function(){
      getInfoData();
      myTimerFunction1();
    }, 2000);
  };

  function myStopFunction() {
    clearTimeout(myTimer1);
  }

  myTimerFunction1();

  </script>

  <style>

  .mybutton {
    background-color: white;
    color: black;
    border: 2px solid #4CAF50;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    // -webkit-transition-duration: 0.1s; /* Safari */
    // transition-duration: 0.1s;
    cursor: pointer;
  }

  .mybutton:hover {
    background-color: #4CAF50;
    color: white;
  }
  .grid {

    display:flex;
    flex-direction:column;
    width: 100%;
    // display: grid;
    // grid-template-areas: "a a";
    // grid-gap: 20px 5px;
    // grid-auto-rows: 100px;
  }

  .grid > label {
    background-color: lime;
  }
  </style>
)=====";
